For more information mraiur.com

Make the file executable:

	chmod +x get_table.sh

Run the script:
	
	./get_table.sh DATABASE_NAME