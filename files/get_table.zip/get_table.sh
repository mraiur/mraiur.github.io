#!/bin/sh

#remote server
REMOVE_FILE="/tmp/table.sql";
REMOTE_USER="EXAMPLE_USER";
REMOTE_PASSWORD="EXAMPLE PASSWORD";

#local parameters
LOCAL_FILE="/tmp/table.sql";
LOCAL_USER="EXAMPLE_USER";
LOCAL_PASSWORD="EXAMPLE PASSWORD";

#export the remote table to a file
DUMP_COMMAND="mysqldump --user=$REMOTE_USER --password=$REMOTE_PASSWORD --databases $1 > $REMOVE_FILE";

#show a message for the current table for downloading
echo "Connect & dump table: $1";
ssh remote_user@example.com $DUMP_COMMAND;

echo "download sql file";
scp remote_user@example.com:$REMOVE_FILE $LOCAL_FILE;

echo "import sql";
mysql --user=$LOCAL_USER --password=$LOCAL_PASSWORD $1 < $LOCAL_FILE;